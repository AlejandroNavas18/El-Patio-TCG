import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore'; // Importación correcta

const firebaseConfig = {
  apiKey: "AIzaSyBYEGCyx7e34yN5KTt6lLzwq-EX1R8iFuQ",
  authDomain: "elpatiotcg.firebaseapp.com",
  projectId: "elpatiotcg",
  storageBucket: "elpatiotcg.firebasestorage.app",
  messagingSenderId: "478600860654",
  appId: "1:478600860654:web:b9451f07b3368b5bb234ff"
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };