import { Redirect } from 'expo-router';

export default function Index() {
  // Solo redirige al flujo de autenticación definido en _layout
  return <Redirect href="/(auth)/login" />;
}