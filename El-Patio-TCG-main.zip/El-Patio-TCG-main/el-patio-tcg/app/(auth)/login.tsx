import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { auth, db } from '../../lib/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { Stack } from 'expo-router';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) return Alert.alert('Error', 'Rellena todos los campos');
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      Alert.alert('Error', 'Usuario o contraseña incorrectos');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!email || !password) return Alert.alert('Error', 'Rellena todos los campos');
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await setDoc(doc(db, "users", userCredential.user.uid), {
        id: userCredential.user.uid,
        username: email.split('@')[0],
        email: email,
        monedas: 500,
        stats: { victorias: 0, derrotas: 0, partidasJugadas: 0 },
        inventario: []
      });
      Alert.alert('Éxito', 'Cuenta creada');
    } catch (error: any) {
      Alert.alert('Error', 'No se pudo crear la cuenta');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <Text style={styles.title}>EL PATIO TCG</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Email"
        placeholderTextColor="#94a3b8"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
      />
      
      <TextInput
        style={styles.input}
        placeholder="Contraseña"
        placeholderTextColor="#94a3b8"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      {loading ? (
        <ActivityIndicator size="large" color="#fbbf24" />
      ) : (
        <View style={{ gap: 15 }}>
          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>INICIAR SESIÓN</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.registerButton} onPress={handleRegister}>
            <Text style={styles.registerText}>CREAR CUENTA NUEVA</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f172a', justifyContent: 'center', padding: 25 },
  title: { fontSize: 32, fontWeight: '900', color: '#fbbf24', textAlign: 'center', marginBottom: 40 },
  input: { backgroundColor: '#1e293b', color: 'white', padding: 18, borderRadius: 12, marginBottom: 15, borderWidth: 1, borderColor: '#334155' },
  button: { backgroundColor: '#fbbf24', padding: 18, borderRadius: 12, alignItems: 'center' },
  buttonText: { color: '#0f172a', fontWeight: 'bold' },
  registerButton: { padding: 18, borderRadius: 12, alignItems: 'center', borderWidth: 1, borderColor: '#fbbf24' },
  registerText: { color: '#fbbf24', fontWeight: 'bold' },
});