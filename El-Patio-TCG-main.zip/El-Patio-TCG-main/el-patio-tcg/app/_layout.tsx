import { Stack, useRouter, useSegments } from 'expo-router';
import { GameProvider, useGame } from '../context/GameContext';
import { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';

function RootLayoutNav() {
  const { user, loading } = useGame();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;

    const inAuthGroup = segments[0] === '(auth)';

    if (!user && !inAuthGroup) {
      // Si no hay usuario, va al login
      router.replace('/(auth)/login' as any);
    } else if (user && inAuthGroup) {
      // CORRECCIÓN: Te mando a la raíz de tabs (index.tsx), no a /home
      router.replace('/(tabs)/' as any); 
    }
  }, [user, loading, segments]);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0f172a' }}>
        <ActivityIndicator size="large" color="#fbbf24" />
      </View>
    );
  }

  return (
    <Stack>
      <Stack.Screen name="(auth)" options={{ headerShown: false }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="index" options={{ headerShown: false }} />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <GameProvider>
      <RootLayoutNav />
    </GameProvider>
  );
}