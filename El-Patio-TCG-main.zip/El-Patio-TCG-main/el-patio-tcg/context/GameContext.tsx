import { Card } from '@/types/Card';
import { User } from '@/types/User';
import React, { createContext, useContext, useState, useEffect } from 'react';
import data from '@/assets/data/cards.json';

// 1. Importamos los tipos oficiales
import { User as FirebaseUser, Auth } from 'firebase/auth';
import { Firestore, doc, onSnapshot } from 'firebase/firestore';

// 2. Importamos y forzamos el tipo en la misma línea para que no exista 'any' en ningún momento
const { auth, db } = require('../lib/firebase') as { auth: Auth; db: Firestore };


interface GameContextType {
    user: User | null;
    loading: boolean; 
    allCards: Card[];
    agregarCarta: (nuevaCarta: Card) => void;
    gastarMonedas: (cantidad: number) => boolean;
    hasCard: (id: string | number) => boolean;
    registrarResultado: (gano: boolean) => void;
    selectedTeam: Card[];
    selectedCoach: Card | null;
    toggleCardToTeam: (card: Card) => void;
    selectCoach: (coach: Card | null) => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider = ({ children }: { children: React.ReactNode }) => {
    const allCards = data.cartas as unknown as Card[];
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true); 

    const [selectedTeam, setSelectedTeam] = useState<Card[]>([]);
    const [selectedCoach, setSelectedCoach] = useState<Card | null>(null);

    useEffect(() => {
        // Al haber tipado 'auth' arriba como 'Auth', onAuthStateChanged ya es reconocido
        const unsubscribeAuth = auth.onAuthStateChanged((firebaseUser: FirebaseUser | null) => {
            if (firebaseUser) {
                const userDocRef = doc(db, "users", firebaseUser.uid);
                const unsubscribeDoc = onSnapshot(userDocRef, (docSnap) => {
                    if (docSnap.exists()) {
                        setUser(docSnap.data() as User);
                    }
                    setLoading(false);
                });
                return () => unsubscribeDoc();
            } else {
                setUser(null);
                setLoading(false);
            }
        });
        return () => unsubscribeAuth();
    }, []);

    // ... (El resto de tus funciones: hasCard, agregarCarta, gastarMonedas, etc. se mantienen igual)
    const hasCard = (id: string | number) => user?.inventario.some(c => c.id === id) || false;

    const agregarCarta = (nuevaCarta: Card) => {
        if (!user) return;
        setUser(prev => prev ? ({ ...prev, inventario: [...prev.inventario, nuevaCarta] }) : null);
    };

    const gastarMonedas = (cantidad: number) => {
        if (user && user.monedas >= cantidad) {
            setUser(prev => prev ? ({ ...prev, monedas: prev.monedas - cantidad }) : null);
            return true;
        }
        return false;
    };

    const registrarResultado = (gano: boolean) => {
        if (!user) return;
        setUser(prev => prev ? ({
            ...prev,
            stats: {
                ...prev.stats,
                partidasJugadas: prev.stats.partidasJugadas + 1,
                victorias: gano ? prev.stats.victorias + 1 : prev.stats.victorias,
                derrotas: !gano ? prev.stats.derrotas + 1 : prev.stats.derrotas,
            }
        }) : null);
    };

    const toggleCardToTeam = (card: Card) => {
        setSelectedTeam(prev => {
            if (prev.find(c => c.id === card.id)) return prev.filter(c => c.id !== card.id);
            if (prev.length >= 7 || card.rareza === 'Entrenador') return prev;
            return [...prev, card];
        });
    };

    const selectCoach = (coach: Card | null) => {
        if (!coach) {
            setSelectedCoach(null);
            return;
        }
        if (coach.rareza === 'Entrenador') setSelectedCoach(coach);
    };

    return (
        <GameContext.Provider value={{
            user, loading, allCards, agregarCarta, gastarMonedas, hasCard,
            registrarResultado, selectedTeam, selectedCoach, toggleCardToTeam, selectCoach
        }}>
            {children}
        </GameContext.Provider>
    );
};

export const useGame = () => {
    const context = useContext(GameContext);
    if (!context) throw new Error('useGame debe usarse dentro de GameProvider');
    return context;
};